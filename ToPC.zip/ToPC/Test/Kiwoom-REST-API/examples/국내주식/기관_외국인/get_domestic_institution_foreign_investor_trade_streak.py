# ---
# api_id: ka10131
# api_name: 기관외국인연속매매현황요청
# category: 국내주식
# sub_category: 기관/외국인
# template: rest
# api_url: /api/dostk/frgnistt
# menu_path: 국내주식 > 기관/외국인 > 기관외국인연속매매현황요청(ka10131)
# ---

import logging
import time

import pandas as pd

from kiwoom import get_client, KiwoomError

API_ID = "ka10131"
API_URL = "/api/dostk/frgnistt"
MAX_PAGES = 10 # 최대 조회 페이지 수
REQUEST_DELAY_SECONDS = 0.2 # 요청 간격 (초)
MESSAGE_KEY = "메시지"
MESSAGE_COLUMNS = {
    "return_code": "응답코드",
    "return_msg": "응답메시지"
}
TABLE_KEYS = {
    "orgn_frgnr_cont_trde_prst": "기관외국인연속매매현황"
}
COLUMNS = {
    "rank": "순위",
    "stk_cd": "종목코드",
    "stk_nm": "종목명",
    "prid_stkpc_flu_rt": "기간중주가등락률",
    "orgn_nettrde_amt": "기관순매매금액",
    "orgn_nettrde_qty": "기관순매매량",
    "orgn_cont_netprps_dys": "기관계연속순매수일수",
    "orgn_cont_netprps_qty": "기관계연속순매수량",
    "orgn_cont_netprps_amt": "기관계연속순매수금액",
    "frgnr_nettrde_qty": "외국인순매매량",
    "frgnr_nettrde_amt": "외국인순매매액",
    "frgnr_cont_netprps_dys": "외국인연속순매수일수",
    "frgnr_cont_netprps_qty": "외국인연속순매수량",
    "frgnr_cont_netprps_amt": "외국인연속순매수금액",
    "nettrde_qty": "순매매량",
    "nettrde_amt": "순매매액",
    "tot_cont_netprps_dys": "합계연속순매수일수",
    "tot_cont_nettrde_qty": "합계연속순매매수량",
    "tot_cont_netprps_amt": "합계연속순매수금액"
}


NUMERIC_COLUMNS = (
    '기간중주가등락률',
    '기관계연속순매수금액',
    '기관계연속순매수량',
    '기관순매매금액',
    '외국인연속순매수금액',
    '외국인연속순매수량',
    '합계연속순매매수량',
    '합계연속순매수금액',
)

def _format_display(df: pd.DataFrame) -> pd.DataFrame:
    display = df.copy()
    for column in tuple(NUMERIC_COLUMNS):
        if column in display.columns:
            display[column] = display[column].map(_format_display_value)
    return display


def _format_display_value(value: object) -> object:
    if value is None or isinstance(value, (dict, list, tuple, set)):
        return value
    try:
        if pd.isna(value):
            return value
    except (TypeError, ValueError):
        return value
    text = str(value).strip()
    sign = "-" if text.startswith("-") else ""
    unsigned = text[1:] if sign else text
    if "." in unsigned:
        integer, fraction = unsigned.split(".", 1)
        if integer.isdigit() and fraction.isdigit():
            return f"{sign}{int(integer or '0'):,}.{fraction}"
        return value
    if unsigned.isdigit() and len(unsigned) >= 6:
        return f"{sign}{int(unsigned or '0'):,}"
    return value

def get_domestic_institution_foreign_investor_trade_streak(
    dt: str,
    mrkt_tp: str,
    netslmt_tp: str,
    stk_inds_tp: str,
    amt_qty_tp: str,
    stex_tp: str,
    strt_dt: str | None = '',
    end_dt: str | None = '',
) -> dict[str, pd.DataFrame]:
    """
    기관외국인연속매매현황요청[ka10131] API를 호출합니다.

    공통 클라이언트가 유효한 캐시 토큰을 사용하거나 필요 시 자동으로 발급합니다.

    Args:
        dt: 기간 — 1:최근일, 3:3일, 5:5일, 10:10일, 20:20일, 120:120일, 0:시작일자/종료일자로 조회
        mrkt_tp: 장구분 — 001:코스피, 101:코스닥
        netslmt_tp: 순매도수구분 — 2:순매수(고정값)
        stk_inds_tp: 종목업종구분 — 0:종목(주식),1:업종
        amt_qty_tp: 금액수량구분 — 0:금액, 1:수량
        stex_tp: 거래소구분 — 1:KRX, 2:NXT, 3:통합
        strt_dt: 시작일자 — YYYYMMDD
        end_dt: 종료일자 — YYYYMMDD

    Returns:
        API 응답 데이터입니다.

    Example:
        >>> result = get_domestic_institution_foreign_investor_trade_streak(
        ...     dt='1',
        ...     mrkt_tp='001',
        ...     netslmt_tp='2',
        ...     stk_inds_tp='0',
        ...     amt_qty_tp='0',
        ...     stex_tp='1',
        ...     strt_dt='',
        ...     end_dt='',
        ... )
        >>> for key, df in result.items():
        ...     print(key, df)
    """

    # 1. 필수 파라미터 검증
    if not dt:
        raise ValueError('dt is required.')
    if not mrkt_tp:
        raise ValueError('mrkt_tp is required.')
    if not netslmt_tp:
        raise ValueError('netslmt_tp is required.')
    if not stk_inds_tp:
        raise ValueError('stk_inds_tp is required.')
    if not amt_qty_tp:
        raise ValueError('amt_qty_tp is required.')
    if not stex_tp:
        raise ValueError('stex_tp is required.')

    # 2. 요청 파라미터 바디
    body = {
        "dt": dt,  # 기간
        "mrkt_tp": mrkt_tp,  # 장구분
        "netslmt_tp": netslmt_tp,  # 순매도수구분
        "stk_inds_tp": stk_inds_tp,  # 종목업종구분
        "amt_qty_tp": amt_qty_tp,  # 금액수량구분
        "stex_tp": stex_tp,  # 거래소구분
    }
    if strt_dt is not None:
        body["strt_dt"] = strt_dt  # 시작일자
    if end_dt is not None:
        body["end_dt"] = end_dt  # 종료일자

    # 3. 인증 클라이언트
    client = get_client()

    # 4. 응답 데이터 저장소
    message_rows = []
    rows = {
        "orgn_frgnr_cont_trde_prst": [],
    }
    # 5. API 호출 및 연속조회
    next_cont_yn = None
    next_key = None

    for page in range(MAX_PAGES):
        response = client.fetch_page(
            api_id=API_ID,
            path=API_URL,
            body=body,
            cont_yn=next_cont_yn,
            next_key=next_key,
        )
        response_body = response.body
        if response_body.get("return_code") not in (None, 0):
            message_rows.append({
                key: response_body.get(key)
                for key in MESSAGE_COLUMNS
            })
        for key in rows:
            records = response_body.get(key, [])
            if isinstance(records, list):
                column_keys = list(COLUMNS)
                for record in records:
                    if isinstance(record, dict):
                        rows[key].append(record)
                    elif isinstance(record, (list, tuple)):
                        rows[key].append(dict(zip(column_keys, record)))

        next_cont_yn = response.continuation.cont_yn
        next_key = response.continuation.next_key

        if next_cont_yn != "Y":
            break

        if page + 1 >= MAX_PAGES:
            break

        time.sleep(REQUEST_DELAY_SECONDS)

    # 6. DataFrame 변환
    result = {
        TABLE_KEYS.get(key, key): pd.DataFrame(records).rename(columns=COLUMNS)
        for key, records in rows.items()
    }
    if message_rows:
        result = {
            MESSAGE_KEY: pd.DataFrame(message_rows).rename(columns=MESSAGE_COLUMNS),
            **result,
        }
    return result


if __name__ == "__main__":
    # 로깅 설정
    logging.basicConfig(level=logging.INFO)
    # 출력 옵션 설정
    pd.set_option("display.max_columns", None)
    pd.set_option("display.width", 160)

    # API 호출
    try:
        result = get_domestic_institution_foreign_investor_trade_streak(
            dt='1',
            mrkt_tp='001',
            netslmt_tp='2',
            stk_inds_tp='0',
            amt_qty_tp='0',
            stex_tp='1',
            strt_dt='',
            end_dt='',
        )
    except KiwoomError as exc:
        raise SystemExit(str(exc))
    # 결과 출력
    for key, df in result.items():
        print(f"\n[{key}]")
        print(_format_display(df))
