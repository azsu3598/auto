# ---
# api_id: ka90008
# api_name: 종목시간별프로그램매매추이요청
# category: 국내주식
# sub_category: 시세
# template: rest
# api_url: /api/dostk/mrkcond
# menu_path: 국내주식 > 시세 > 종목시간별프로그램매매추이요청(ka90008)
# ---

import logging
import time

import pandas as pd

from kiwoom import get_client, KiwoomError

API_ID = "ka90008"
API_URL = "/api/dostk/mrkcond"
MAX_PAGES = 10 # 최대 조회 페이지 수
REQUEST_DELAY_SECONDS = 0.2 # 요청 간격 (초)
MESSAGE_KEY = "메시지"
MESSAGE_COLUMNS = {
    "return_code": "응답코드",
    "return_msg": "응답메시지"
}
TABLE_KEYS = {
    "stk_tm_prm_trde_trnsn": "종목시간별프로그램매매추이"
}
COLUMNS = {
    "tm": "시간",
    "cur_prc": "현재가",
    "pre_sig": "대비기호",
    "pred_pre": "전일대비",
    "flu_rt": "등락율",
    "trde_qty": "거래량",
    "prm_sell_amt": "프로그램매도금액",
    "prm_buy_amt": "프로그램매수금액",
    "prm_netprps_amt": "프로그램순매수금액",
    "prm_netprps_amt_irds": "프로그램순매수금액증감",
    "prm_sell_qty": "프로그램매도수량",
    "prm_buy_qty": "프로그램매수수량",
    "prm_netprps_qty": "프로그램순매수수량",
    "prm_netprps_qty_irds": "프로그램순매수수량증감",
    "base_pric_tm": "기준가시간",
    "dbrt_trde_rpy_sum": "대차거래상환주수합",
    "remn_rcvord_sum": "잔고수주합",
    "stex_tp": "거래소구분"
}


NUMERIC_COLUMNS = (
    '거래량',
    '등락율',
    '잔고수주합',
    '프로그램매도금액',
    '프로그램매도수량',
    '프로그램매수금액',
    '프로그램매수수량',
    '프로그램순매수금액',
    '프로그램순매수금액증감',
    '프로그램순매수수량',
    '프로그램순매수수량증감',
    '현재가',
)

def _format_display(df: pd.DataFrame) -> pd.DataFrame:
    display = df.copy()
    for column in tuple(NUMERIC_COLUMNS):
        if column in display.columns:
            display[column] = display[column].map(_format_display_value)
    return display


def _format_display_value(value: object) -> object:
    if value is None or isinstance(value, (dict, list, tuple, set)):
        return value
    try:
        if pd.isna(value):
            return value
    except (TypeError, ValueError):
        return value
    text = str(value).strip()
    sign = "-" if text.startswith("-") else ""
    unsigned = text[1:] if sign else text
    if "." in unsigned:
        integer, fraction = unsigned.split(".", 1)
        if integer.isdigit() and fraction.isdigit():
            return f"{sign}{int(integer or '0'):,}.{fraction}"
        return value
    if unsigned.isdigit() and len(unsigned) >= 6:
        return f"{sign}{int(unsigned or '0'):,}"
    return value

def get_domestic_stock_program_intraday_trend(
    amt_qty_tp: str,
    stk_cd: str,
    date: str,
) -> dict[str, pd.DataFrame]:
    """
    종목시간별프로그램매매추이요청[ka90008] API를 호출합니다.

    공통 클라이언트가 유효한 캐시 토큰을 사용하거나 필요 시 자동으로 발급합니다.

    Args:
        amt_qty_tp: 금액수량구분 — 1:금액, 2:수량
        stk_cd: 종목코드 — 거래소별 종목코드
            (KRX:039490,NXT:039490_NX,SOR:039490_AL)
        date: 날짜 — YYYYMMDD

    Returns:
        API 응답 데이터입니다.

    Example:
        >>> result = get_domestic_stock_program_intraday_trend(
        ...     amt_qty_tp='1',
        ...     stk_cd='005930',
        ...     date='20241125',
        ... )
        >>> for key, df in result.items():
        ...     print(key, df)
    """

    # 1. 필수 파라미터 검증
    if not amt_qty_tp:
        raise ValueError('amt_qty_tp is required.')
    if not stk_cd:
        raise ValueError('stk_cd is required.')
    if not date:
        raise ValueError('date is required.')

    # 2. 요청 파라미터 바디
    body = {
        "amt_qty_tp": amt_qty_tp,  # 금액수량구분
        "stk_cd": stk_cd,  # 종목코드
        "date": date,  # 날짜
    }

    # 3. 인증 클라이언트
    client = get_client()

    # 4. 응답 데이터 저장소
    message_rows = []
    rows = {
        "stk_tm_prm_trde_trnsn": [],
    }
    # 5. API 호출 및 연속조회
    next_cont_yn = None
    next_key = None

    for page in range(MAX_PAGES):
        response = client.fetch_page(
            api_id=API_ID,
            path=API_URL,
            body=body,
            cont_yn=next_cont_yn,
            next_key=next_key,
        )
        response_body = response.body
        if response_body.get("return_code") not in (None, 0):
            message_rows.append({
                key: response_body.get(key)
                for key in MESSAGE_COLUMNS
            })
        for key in rows:
            records = response_body.get(key, [])
            if isinstance(records, list):
                column_keys = list(COLUMNS)
                for record in records:
                    if isinstance(record, dict):
                        rows[key].append(record)
                    elif isinstance(record, (list, tuple)):
                        rows[key].append(dict(zip(column_keys, record)))

        next_cont_yn = response.continuation.cont_yn
        next_key = response.continuation.next_key

        if next_cont_yn != "Y":
            break

        if page + 1 >= MAX_PAGES:
            break

        time.sleep(REQUEST_DELAY_SECONDS)

    # 6. DataFrame 변환
    result = {
        TABLE_KEYS.get(key, key): pd.DataFrame(records).rename(columns=COLUMNS)
        for key, records in rows.items()
    }
    if message_rows:
        result = {
            MESSAGE_KEY: pd.DataFrame(message_rows).rename(columns=MESSAGE_COLUMNS),
            **result,
        }
    return result


if __name__ == "__main__":
    # 로깅 설정
    logging.basicConfig(level=logging.INFO)
    # 출력 옵션 설정
    pd.set_option("display.max_columns", None)
    pd.set_option("display.width", 160)

    # API 호출
    try:
        result = get_domestic_stock_program_intraday_trend(
            amt_qty_tp='1',
            stk_cd='005930',
            date='20241125',
        )
    except KiwoomError as exc:
        raise SystemExit(str(exc))
    # 결과 출력
    for key, df in result.items():
        print(f"\n[{key}]")
        print(_format_display(df))
