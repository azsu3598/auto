# ---
# api_id: FT
# api_name: 미국주식 10호가
# category: 미국주식
# sub_category: 실시간시세
# template: websocket_realtime
# api_url: /api/us/websocket
# menu_path: 미국주식 > 실시간시세 > 미국주식 10호가(FT)
# ---

import asyncio
import logging
from typing import Any

from kiwoom import get_ws_client
from kiwoom.realtime import event_to_dataframe, run_pubsub

# 미국주식 10호가(FT) 실시간 구독 — 한 스트림을 여러 소비자에 분배
# in-process Pub/Sub(asyncio.Queue). LOGIN/PING은 공통 클라이언트가 처리합니다.

API_URL = "/api/us/websocket"
COLUMNS = {
    '21': '시간',
    '41': '매도1호가',
    '61': '매도1호가잔량',
    '81': '매도1호가직전대비',
    '51': '매수1호가',
    '71': '매수1호가잔량',
    '91': '매수1호가직전대비',
    '42': '매도2호가',
    '62': '매도2호가잔량',
    '82': '매도2호가직전대비',
    '52': '매수2호가',
    '72': '매수2호가잔량',
    '92': '매수2호가직전대비',
    '43': '매도3호가',
    '63': '매도3호가잔량',
    '83': '매도3호가직전대비',
    '53': '매수3호가',
    '73': '매수3호가잔량',
    '93': '매수3호가직전대비',
    '44': '매도4호가',
    '64': '매도4호가잔량',
    '84': '매도4호가직전대비',
    '54': '매수4호가',
    '74': '매수4호가잔량',
    '94': '매수4호가직전대비',
    '45': '매도5호가',
    '65': '매도5호가잔량',
    '85': '매도5호가직전대비',
    '55': '매수5호가',
    '75': '매수5호가잔량',
    '95': '매수5호가직전대비',
    '46': '매도6호가',
    '66': '매도6호가잔량',
    '86': '매도6호가직전대비',
    '56': '매수6호가',
    '76': '매수6호가잔량',
    '96': '매수6호가직전대비',
    '47': '매도7호가',
    '67': '매도7호가잔량',
    '87': '매도7호가직전대비',
    '57': '매수7호가',
    '77': '매수7호가잔량',
    '97': '매수7호가직전대비',
    '48': '매도8호가',
    '68': '매도8호가잔량',
    '88': '매도8호가직전대비',
    '58': '매수8호가',
    '78': '매수8호가잔량',
    '98': '매수8호가직전대비',
    '49': '매도9호가',
    '69': '매도9호가잔량',
    '89': '매도9호가직전대비',
    '59': '매수9호가',
    '79': '매수9호가잔량',
    '99': '매수9호가직전대비',
    '50': '매도10호가',
    '70': '매도10호가잔량',
    '90': '매도10호가직전대비',
    '60': '매수10호가',
    '80': '매수10호가잔량',
    '100': '매수10호가직전대비',
    '121': '매도호가총잔량',
    '122': '매도호가총잔량직전대비',
    '125': '매수호가총잔량',
    '126': '매수호가총잔량직전대비',
}


async def print_dataframe(queue: asyncio.Queue[Any]) -> None:
    # "kiwoom.realtime" 토픽: REAL 이벤트만 도착 → DataFrame으로 출력
    while True:
        event = await queue.get()
        print(event_to_dataframe(event), flush=True)


async def log_raw(queue: asyncio.Queue[Any]) -> None:
    # "kiwoom.all" 토픽: REG/SYSTEM 포함 모든 메시지를 원본 그대로 출력
    while True:
        event = await queue.get()
        print(event, flush=True)


async def main() -> None:
    logging.basicConfig(level=logging.INFO)

    # Kiwoom 실시간 등록 패킷(REG)
    body = {
        "trnm": "REG",  # 등록("0"이면 해제)
        "grp_no": "1",  # 그룹번호
        "refresh": "1",  # 기존 등록 유지 여부
        # 등록할 종목(item)과 실시간 타입(type)
        "data": [{"item": [{'jmcode': 'NVDA', 'stex_tp': 'ND'}], "type": ['FT']}],
    }

    # 같은 스트림을 두 소비자에 분배: 가공(print_dataframe) / 원본 로깅(log_raw)
    await run_pubsub(
        get_ws_client(),
        api_url=API_URL,
        bodies=body,
        consumers={
            "kiwoom.realtime": print_dataframe,
            "kiwoom.all": log_raw,
        },
        columns=COLUMNS,
        max_messages=10,
    )


if __name__ == "__main__":
    asyncio.run(main())
