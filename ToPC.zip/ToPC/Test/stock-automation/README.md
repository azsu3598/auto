# Stock Automation MVP

한국 주식 종가배팅을 예약 실행하기 위한 **분석·모의매매 우선** 엔진이다. AWS
기본 배포는 키움 모의투자 키만 사용하며 실제 주문 권한이 없다. 별도의 수동
`live-*` CLI에는 실주문 API 호출 코드가 존재하지만 기본 비활성화 상태이고,
체결·부분체결 원장이 완성되기 전에는 운영용으로 활성화하지 않는다. 기본 전략은
KRX 15:20이며 NXT 19:55 전략은 별도 세션과 원장으로 명시적으로 실행할 때만
활성화된다.

## 구현 범위

- 거래대금·거래량·종가 강도·일봉·5분봉·VWAP·RSI·ATR·돌파 유지·호가 기반 후보 평가
- KRX 전략의 NXT 대상 종목 강제 제외
- 한 테마당 최대 한 종목 및 최종 0~3개 후보
- 최대 손실 10,000원과 최대 40% 배분을 동시에 지키는 수량 계산
- `IMMEDIATE` / `5M_CONFIRMED` 손절과 다음 거래일 09:10 청산 판단
- 동일 날짜·세션의 중복 모의체결 방지
- 0~100점으로 정규화된 후보 적합도와 검증 촉매 필수 필터
- 09:10 잔여수량 전량 청산 우선 및 1차 부분익절 1회 제한
- JSONL 원장, 기존 형식 CSV 이벤트 및 Markdown 보고서 출력
- 키움 REST API 응답을 정규화하는 스냅샷 빌더
- 종료된 거래의 실제 5분봉 경로 보관과 거래비용 포함 재생 백테스트
- 훈련/검증 시계열을 분리한 주간 챔피언-도전자 규칙 개선(모의전략 한정)
- 모의매수·부분익절·전량매도·손절 및 전략 승격 텔레그램 알림

## 로컬 실행

```bash
cd D:/Test/stock-automation
set PYTHONPATH=src
python -m unittest discover -s tests -v
python -m stock_automation.cli analyze ^
  --snapshot examples/krx_snapshot.json ^
  --ledger runtime/paper-ledger.jsonl ^
  --cash 600000 ^
  --report-dir runtime/reports ^
  --training-events runtime/recommendation-events.csv
```

WSL에서는 `set PYTHONPATH=src` 대신 `PYTHONPATH=src`를 명령 앞에 붙인다.

## 운영 대시보드

`SABU Trading Console`은 모의매매 원장을 읽기 전용으로 보여주는 PC·모바일 대응
운영 화면이다. 가용현금, 투자원금, 실현손익, 열린 포지션, 최근 실행 이력, 전략별
지갑, 일일 예약표와 안전장치 상태를 한 화면에서 확인한다. 실거래 전환은 기존 잔고
보호와 체결 원장 대사가 완성되지 않았으므로 UI에서 강제로 잠겨 있다.

AWS 연결 전 샘플 데이터로 화면을 확인한다.

```bash
PYTHONPATH=src python3 -m stock_automation.cli dashboard \
  --fixture examples/dashboard_fixture.json
```

브라우저에서 `http://127.0.0.1:8765`를 연다. Windows PowerShell에서는 다음과 같다.

```powershell
$env:PYTHONPATH="src"
python -m stock_automation.cli dashboard --fixture examples/dashboard_fixture.json
```

배포 후 실제 모의 원장은 AWS CLI 인증이 된 환경에서 `PAPER_TABLE`을 지정해 읽는다.

```bash
PAPER_TABLE=<DynamoDB 테이블명> PYTHONPATH=src \
  python3 -m stock_automation.cli dashboard
```

현재 서버는 인증되지 않은 외부 노출을 막기 위해 `127.0.0.1`에만 바인딩한다. 인터넷과
휴대폰 외부망에서 접속하는 AWS 웹 콘솔은 Cognito 인증과 HTTPS를 붙인 뒤 별도
배포한다. 포트를 외부에 직접 개방하지 않는다.

배포 전 진단은 비밀값을 출력하지 않고 모의투자 모드, 주문 게이트, 키움·OpenDART
자격증명 존재 여부와 AWS 환경변수를 검사한다. `--online`을 추가하면 주문 없이
키움 종목목록과 OpenDART 법인코드 읽기만 시험한다.

```bash
stock-automation doctor --aws
stock-automation doctor --aws --online
```

## 입력 데이터 계약

`MarketSnapshot`은 반드시 시간대가 포함된 기준시각, 세션, 시장 등락률, 데이터
출처 및 종목별 `Quote`를 제공해야 한다. 종목에는 현재가·고저가·거래량·거래대금,
전일 거래량, 5/20/60/120일선, RSI(14), ATR(14), 5분 20이평과 기울기,
세션 VWAP, 마감 거래량 팽창, 고점·저점 상승 구조, 돌파 유지, 구조적 지지선과
NXT 여부가 필요하다. 뉴스·테마는 차트보다 낮은 비중의 보조 맥락이다. 지연
데이터이거나 지지선·분봉 이력이 불충분하면 프로그램은 해당 종목을 제외한다.

키움 어댑터는 다음 공식 API를 사용한다.

- `ka10099`: 종목정보 및 NXT 가능 여부
- `ka10032`: 거래대금 상위
- `ka10007`: 현재 시세와 호가
- `ka10081`: 일봉
- `ka10080`: 5분봉

촉매와 테마는 별도 뉴스/공시 수집기가 제공해야 한다. 키움 테마 강도는 후보의
맥락으로만 사용하며 검증 촉매로 인정하지 않는다. 날짜별 촉매 파일에서 뉴스·공시가
검증된 종목만 최종 점수 계산으로 진입한다.

키움 `ka10007`, `ka10032`, `ka10081`의 거래대금은 공식 응답 단위가 백만원이므로
어댑터에서 원 단위로 변환한 뒤 유동성 기준과 비교한다. 시가총액(`ka10001.mac`)과
손익 항목의 억원 단위도 중기 스냅샷에서 원으로 정규화한다.

## 1~2개월 보유 전략

`medium-analyze`는 종가배팅과 다른 입력·결정 ID·원장 파일을 사용하는 20~40
거래일 모의전략이다. 20·60·120일선 배열과 기울기, RSI, ATR, 20일 거래량,
20·60일 수익률, 지지·저항 및 손익비를 우선 평가하고 PER·PBR·ROE와 흑자는
안전 필터로 사용한다.

공시 검증이 없거나 감사·상장폐지·자본훼손·희석 이벤트가 있으면 차트 점수가
높아도 매수하지 않는다. 키움은 `ka10001`의 밸류에이션·손익 수치를 제공하지만
공시 위험은 OpenDART `corpCode.xml`과 `list.json`으로 자동 검증한다. 최대 30% 배분, 포지션 손실 2만원,
20거래일 재검토 및 40거래일 최대 보유기간을 종가배팅 계좌와 별도로 적용한다.

장 마감 분석 가격을 체결가로 소급하지 않는다. 15:40에는 신호와 진입 상한만
기록하고, 다음 거래일 09:15에 확인한 가격·공시를 다시 검사해 모의 진입하거나
취소한다. 열린 포지션은 매 거래일 15:35 확인가로 재평가하며 목표가, 투자 논리
훼손, 공시 위험 및 최대 보유기간에 따라 보유·부분익절·전량청산을 결정한다.

```bash
python -m stock_automation.cli medium-analyze ^
  --snapshot runtime/medium-snapshot.json ^
  --ledger runtime/medium-paper-ledger.jsonl ^
  --cash 600000
```

## 안전 경계

- AWS 기본 스택에는 실제 주문 권한과 실계좌 비밀값이 없다.
- API 오류·지연·스냅샷 세션 불일치 시 실패 종료한다.
- 모의 체결은 확인 시점의 최우선 매도호가 또는 현재가를 사용하며 과거 가격으로
  소급하지 않는다.
- KRX와 NXT 전략의 세션·원장·성과를 합치지 않는다.
- 기록 데이터로 개선된 규칙도 `PAPER_ONLY`가 아니면 로드하지 않는다.
- 학습 규칙은 안전 범위 안의 차트 임계값만 바꾸며 주문·자금·손실 한도를
  스스로 변경하지 못한다.
- AWS 배포 전 키움 모의투자 키, Secrets Manager, S3/DynamoDB 저장소와 거래일
  캘린더를 연결해야 한다.

수동 실주문 CLI는 코드에 포함돼 있지만 AWS 모의전략 결정과 자동 연결되어 있지
않다. 향후 실주문을 승인하더라도 기본값은 비활성화이며, 정확한 주문내용 해시와
5분 이내 사용자 승인, 최신 시세, 주문·총노출·일손실·보유종목 한도, 중복 주문
방지, 계좌 별칭 일치 및 비상정지 해제를 모두 통과해야만 승인 상태가 된다. 가격,
수량 또는 계좌가 바뀌면 기존 승인은 즉시 무효다. 주문번호 수신은 체결이 아니므로
실거래 활성화 전 체결·부분체결·미체결·취소를 계좌 및 원장과 대조하는 별도 흐름이
반드시 추가되어야 한다.

## 컨테이너

저장소 루트 `D:/Test`를 빌드 컨텍스트로 사용한다.

```bash
docker build -f stock-automation/Dockerfile -t stock-automation:dev .
```

초기 AWS 운영 형태는 EventBridge Scheduler가 필요한 시각에만 ECS Fargate 작업을
실행하고 완료 즉시 종료하는 방식이다. 24시간 컨테이너와 실계좌 주문은 범위 밖이다.

## AWS 예약 작업

`infra/cloudformation.yaml`은 다음 모의매매 작업을 만든다.

안전한 최초 배포를 위해 모든 핵심 예약은 `CoreScheduleState=DISABLED`가 기본값이다.
거래일 파일 업로드와 `doctor --aws --online` 읽기 전용 점검을 통과한 뒤에만
`ENABLED`로 스택을 갱신한다. NXT는 별도 `NxtScheduleState`를 명시적으로 켜야 한다.

- 14:50 KST: KRX 전체 후보 스캔 스냅샷
- 15:10 KST: 후보 재검증 스냅샷
- 15:20 KST: KRX 최종 `BUY` 또는 `NO_TRADE`
- 19:55 KST: NXT 최종 판단(기본 `DISABLED`)
- 다음 거래일 09:05 KST: 비상 손절·목표가 조기 점검
- 다음 거래일 09:10 KST: 남은 수량 모의청산
- 토요일 08:00 KST: 종료 거래를 이용한 주간 워크포워드 튜닝
- 15:40 KST: 별도 중기 전략 신호 생성(당일 체결 없음)
- 다음 거래일 09:15 KST: 중기 신호 가격·공시 재검증 후 모의 진입 또는 취소
- 15:35 KST: 열린 중기 포지션 종가 재평가 및 모의 매도 판단

결과와 원본 스냅샷은 S3, 멱등 모의체결과 열린 포지션은 DynamoDB 온디맨드에
저장한다. 같은 날짜·세션을 재실행해도 조건부 쓰기로 중복 포지션을 만들지 않는다.
KRX 종가배팅, NXT 종가배팅, 중기 전략은 각각 별도 `WALLET`을 사용한다. 매수 시
원금과 매수 수수료를 차감하고 매도 시 수수료·세금을 제외한 순매도대금을 더하므로,
다음 거래의 수량은 고정 초기금이 아닌 누적 가용현금으로 계산된다. 총비용과 순실현
손익도 매매 이벤트와 같은 DynamoDB 트랜잭션으로 갱신된다.
키움 키는 Secrets Manager의 `app_key_mock`, `app_secret_mock` 필드에서 ECS 비밀
환경변수로 주입하며, Task Role에는 주식 주문 권한이 없다.

모의매수·부분익절·전량매도·손절이 원장에 처음 기록되면 휴대폰 텔레그램으로
알림을 보낸다. 텔레그램 Bot API 자체에는 발송 비용이 없고 별도의 상시 실행
프로세스도 필요하지 않다. 재시도나 중복 예약 실행은 조건부 원장 쓰기로 같은
모의체결을 다시 만들지 않는다. 매매 이벤트와 알림 outbox를 하나의 DynamoDB
트랜잭션으로 저장하므로 메신저 장애가 나도 알림을 `PENDING`으로 남겨 동일 예약
작업의 재시도에서 다시 전송한다. 외부 메신저 응답 직후 작업이 중단되는 극히 드문 경우에는 중복 알림이
가능하므로 메시지의 이벤트 ID를 기준으로 구분한다. 실제 주문을 도입할 때는 주문 접수와 체결 확인을
별도 이벤트로 나누고, **키움 체결 확인이 끝난 뒤에만** 사용자 알림을 보내도록
연결한다. 현재 알림에는 `모의매매`가 명시된다.

### 텔레그램 알림 준비

1. 텔레그램 `@BotFather`에서 `/newbot`으로 봇을 만든다.
2. 생성한 봇과의 대화에서 `/start`를 한 번 보낸다.
3. Bot API `getUpdates` 결과의 `message.chat.id`를 확인한다.
4. Secrets Manager JSON에 `bot_token`, `chat_id`를 저장한다.
5. 배포 파라미터 `NotificationChannel=telegram`과
   `NotificationSecretArn=<해당 Secret ARN>`을 전달한다.

봇 토큰은 비밀번호처럼 취급하며 코드·로그·S3에 기록하지 않는다. 알림용 JSON은
기존 키움 Secret에 필드를 추가해 같은 ARN을 전달해도 되므로 별도 Secret이
필수는 아니다. 카카오 `나에게 보내기` 어댑터도 선택 가능하지만 OAuth 갱신과 앱
설정이 더 복잡하므로 기본값은 텔레그램이다. 기존 이메일 기능도 삭제하지 않았다.
`NotificationChannel=email`과 `NotificationEmail`을 지정하면 SNS 구독 확인 후
이메일로 동일한 알림을 받을 수 있다.

## 기록 기반 자동 개선

전량 청산된 포지션은 진입 당시 스냅샷과 이후 실제 5분봉을
`replay-cases/<session>/`에 보관한다. 주간 작업은 시간순으로 앞 70%를 훈련,
뒤 30%를 검증에 사용하고 기존 챔피언보다 검증 성과가 나은 도전자만 승격한다.
최소 40건, 최소 검증 거래 5건, 순이익 양수, 최대낙폭 제한을 모두 통과해야 한다.

자동 조정 대상은 다음 다섯 가지뿐이다.

- 최소 차트 점수
- 최소 종가 강도
- 최소 거래량 팽창률
- 허용 일간 상승률 상한
- 5일선 최대 이격도

승격된 설정은 `config/rules/<session>.json`에 `PAPER_ONLY`로 저장된다. KRX와
NXT는 별도로 학습한다. 실제 주문 모드로 자동 전환하거나 실거래 규칙을 자동
교체하는 경로는 없다.

배포 전 거래일 파일은 반드시 넣고, 검증된 뉴스 촉매가 있을 때 촉매 파일을 추가한다.

```text
config/calendar/current.json
config/catalysts/YYYY-MM-DD.json  # 선택
config/dart/corp-code-map.json  # 프로그램이 자동 생성·주 1회 갱신
config/disclosures/YYYY-MM-DD.json  # 프로그램이 자동 생성
```

거래일 파일 예시는 `{"year": 2026, "holidays": ["2026-10-09"]}` 형식이다.
촉매 파일은 종목코드를 키로 하고 `theme`, `summary`, `score`, `verified`,
`source`, 시간대가 포함된 `verified_at`을 제공한다. `verified: true`, 비어 있지
않은 출처, 실행일과 같은 KST 날짜의 검증시각이 모두 있어야 검증 촉매로 인정한다.
예시는 `{"123456":{"theme":"로봇","summary":"수주 공시","score":0.8,
"verified":true,"source":"OpenDART: 20261008000123","verified_at":
"2026-10-08T14:55:00+09:00"}}`이다. 파일이 없거나 조건을 만족하지 못하면 키움
`ka90001`·`ka90002`의 당일 테마 상승률과 상승/하락 종목 폭을 보조
맥락으로만 사용하며 신규 진입은 하지 않는다. 파일에 검증된 뉴스·공시가 있으면
같은 종목의 테마 맥락을 덮어쓰고 최종 평가를 허용한다. 어느 경우에도 뉴스·테마
점수는 차트 점수보다 큰 비중을 갖지 않는다.
중기 공시 파일은 OpenDART 조회 결과를 종목코드별 `checked_at`, `risk_flags`,
`catalyst`, 근거 공시 목록으로 저장한 캐시다. API 키 오류·호출 제한·불완전한
페이지·최신 검증시각 누락이 발생하면 신규 진입은 자동 취소되며, 보유 포지션의
종가 재평가는 검증을 복구할 때까지 실패 종료해 임의 매도를 만들지 않는다.

CloudFormation 배포 시 컨테이너 이미지 URI, 서브넷, 보안 그룹, 키움 모의투자
Secrets Manager ARN, 무료 OpenDART 키의 `DartSecretArn`과 실제 적용 수수료·세금(`BuyFeeBps`, `SellFeeBps`,
`SellTaxBps`)을 파라미터로 전달한다. 텔레그램 알림용
`NotificationSecretArn`도 전달한다. 이메일을 선택하면 대신 `NotificationEmail`을
전달한다. 비용률은 계좌와 시점에 따라 달라질 수 있어 코드에 고정값을 넣지 않았다.
NXT 예약은 KRX 전략과 성과를 섞지 않기 위해 별도 스케줄이며 기본적으로 꺼져 있다.
